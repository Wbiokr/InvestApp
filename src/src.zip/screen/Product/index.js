import React from 'react';
import {
  View,
  Text,
} from 'react-native';

export default class Home extends React.Component{
  render(){
    return <View>
              <Text>产品列表</Text>
            </View>
  }
}