import React from 'react';
import {
  View,
  Text,
} from 'react-native';

export default class Home extends React.Component{
  render(){
    return <View>
              <Text>home页面</Text>
            </View>
  }
}