export default {
  nav:'#393D49',//黑色，通常用于导航
  
  green:'#5FB878',//青绿色一般用于选中状态
  
  blueGreen:'#009688',//蓝绿色，通常用于按钮、及任何修饰元素

  blueLight:'##1E9FFF',//亮蓝色，比较适合一些鲜艳色系的页面

  blueTxt:'#01AAED',//文字着色，用于文字着色，如链接文本

  orange:'#FF5722',//橙色

  yellow:'#FFB800',//黄色 一般用于提示性元素

  bottom:'#2F4056',//底部色

  grayO:'#F0F0F0',

  gray1:'#f2f2f2',

  gray2:'#eee',

  gray3:'#e2e2e2',

  gray4:'#ddd',

  gray5:'#d2d2d2',

  gray6:'#c2c2c2',

  yd:'#ca6',
}